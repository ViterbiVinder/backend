package CS201.Vinder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VinderApplicationTests {

	@Test
	void contextLoads() {
	}

}
