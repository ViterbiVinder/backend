package CS201.Vinder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VinderApplication {

	public static void main(String[] args) {
		SpringApplication.run(VinderApplication.class, args);
	}

}
